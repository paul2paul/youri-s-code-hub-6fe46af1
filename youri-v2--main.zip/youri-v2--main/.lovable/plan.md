
# Ajout des organes de gouvernance optionnels

## Contexte

Actuellement, la page "Profil de gouvernance" affiche uniquement les règles procédurales (délais, quorum, majorités) mais pas la composition des organes de direction de l'entreprise. Pour une SAS, ces organes peuvent inclure :

- **Direction exécutive** : Président, Directeur Général (DG), Directeurs Généraux Délégués
- **Organes collégiaux optionnels** : Comité de direction, Conseil de surveillance, Comité stratégique

## Ce qui sera ajouté

### 1. Nouvelle table `governance_bodies` (organes de gouvernance)

Une nouvelle table pour stocker les organes de gouvernance détectés dans les statuts :

| Colonne | Type | Description |
|---------|------|-------------|
| id | uuid | Identifiant unique |
| company_id | uuid | Référence à l'entreprise |
| body_type | enum | Type d'organe (PRESIDENT, DG, COMITE_DIRECTION, CONSEIL_SURVEILLANCE, etc.) |
| name | text | Nom de l'organe ou du mandataire |
| holder_name | text | Nom du titulaire actuel (si applicable) |
| powers_summary | text | Résumé des pouvoirs |
| appointment_rules | text | Règles de nomination |
| term_duration | text | Durée du mandat |
| extracted_at | timestamp | Date d'extraction |

### 2. Mise à jour de l'Edge Function `analyze-governance`

Modification du prompt IA pour extraire également :
- Les mandataires sociaux (Président, DG)
- Les comités optionnels mentionnés dans les statuts
- Les pouvoirs et limitations de chaque organe
- Les règles de nomination et révocation

### 3. Nouvelle section sur la page Gouvernance

Ajout d'une carte "Organes de direction" affichant :
- Le Président avec ses pouvoirs
- Le DG si présent
- Les comités optionnels avec leur composition et rôle
- Utilisation d'accordéons pour organiser l'information

## Modifications techniques

### Base de données

```sql
-- Création d'un enum pour les types d'organes
CREATE TYPE governance_body_type AS ENUM (
  'PRESIDENT',
  'DIRECTEUR_GENERAL', 
  'DIRECTEUR_GENERAL_DELEGUE',
  'COMITE_DIRECTION',
  'CONSEIL_SURVEILLANCE',
  'COMITE_STRATEGIQUE',
  'OTHER'
);

-- Nouvelle table
CREATE TABLE governance_bodies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
  body_type governance_body_type NOT NULL,
  name text NOT NULL,
  holder_name text,
  powers_summary text,
  appointment_rules text,
  term_duration text,
  created_at timestamptz DEFAULT now()
);

-- Index et RLS
CREATE INDEX idx_governance_bodies_company ON governance_bodies(company_id);
ALTER TABLE governance_bodies ENABLE ROW LEVEL SECURITY;
```

### Fichiers modifiés

1. **`supabase/functions/analyze-governance/index.ts`**
   - Ajout d'un outil IA `extract_governance_bodies` 
   - Insertion des organes détectés dans la nouvelle table

2. **`src/types/database.ts`**
   - Ajout du type `GovernanceBody`
   - Ajout du type `GovernanceBodyType`

3. **`src/hooks/useGovernanceProfile.tsx`**
   - Ajout d'une query pour récupérer les `governance_bodies`

4. **`src/pages/Governance.tsx`**
   - Nouvelle carte "Organes de direction" avec accordéons
   - Affichage du Président, DG, et comités optionnels
   - Icônes appropriées (Crown pour Président, Briefcase pour DG, Users pour comités)

## Maquette de l'interface

```text
+------------------------------------------+
|  Organes de direction                    |
|  [Crown icon]                            |
+------------------------------------------+
|  > Président                             |
|    Titulaire : [Nom du président]        |
|    Pouvoirs : Représente la société...   |
|    Durée du mandat : Illimitée           |
+------------------------------------------+
|  > Directeur Général (si présent)        |
|    Titulaire : [Nom du DG]               |
|    Pouvoirs : Pouvoirs les plus étendus..|
+------------------------------------------+
|  > Comité de direction (si présent)      |
|    Composition : 3 membres minimum       |
|    Rôle : Assiste le Président...        |
+------------------------------------------+
```

## Étapes d'implémentation

1. Créer la migration pour la table `governance_bodies` et l'enum
2. Mettre à jour l'Edge Function pour extraire les organes
3. Ajouter le hook et les types TypeScript
4. Mettre à jour l'interface de la page Gouvernance
5. Re-déclencher l'analyse de gouvernance pour extraire les nouveaux éléments
