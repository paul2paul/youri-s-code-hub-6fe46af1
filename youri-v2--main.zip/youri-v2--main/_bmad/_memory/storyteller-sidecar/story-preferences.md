# Story Record Template

Purpose: Record a log of learned users story telling or story building preferences.

## User Preference Bullet List

<!-- record any user preferences about story crafting the user prefers -->
