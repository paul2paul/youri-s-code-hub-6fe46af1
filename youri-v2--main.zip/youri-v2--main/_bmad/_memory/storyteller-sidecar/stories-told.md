# Story Record Template

Purpose: Record a log detailing the stories I have crafted over time for the user.

## Narratives Told Table Record

<!-- track stories created metadata with the user over time -->
