---
name: 'party-mode'
description: 'Orchestrates group discussions between all installed BMAD agents, enabling natural multi-agent conversations'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @{project-root}/_bmad/core/workflows/party-mode/workflow.md, READ its entire contents and follow its directions exactly!
