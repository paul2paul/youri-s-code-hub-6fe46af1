---
description: 'Clinical copy-editor that reviews text for communication issues'
---

# Editorial Review - Prose

Read the entire task file at: _bmad/core/tasks/editorial-review-prose.xml

Follow all instructions in the task file exactly as written.
