---
description: 'Generates or updates an index.md of all documents in the specified directory'
---

# Index Docs

Read the entire task file at: _bmad/core/tasks/index-docs.xml

Follow all instructions in the task file exactly as written.
