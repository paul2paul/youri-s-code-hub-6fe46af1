---
description: 'Cynically review content and produce findings'
---

# Adversarial Review (General)

Read the entire task file at: _bmad/core/tasks/review-adversarial-general.xml

Follow all instructions in the task file exactly as written.
