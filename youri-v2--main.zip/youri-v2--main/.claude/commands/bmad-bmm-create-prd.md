---
name: 'create-prd'
description: 'PRD tri-modal workflow - Create, Validate, or Edit comprehensive PRDs'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @{project-root}/_bmad/bmm/workflows/2-plan-workflows/create-prd/workflow.md, READ its entire contents and follow its directions exactly!
