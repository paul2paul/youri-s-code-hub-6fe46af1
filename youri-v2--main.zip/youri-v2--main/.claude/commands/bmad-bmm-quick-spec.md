---
name: 'quick-spec'
description: 'Conversational spec engineering - ask questions, investigate code, produce implementation-ready tech-spec.'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @{project-root}/_bmad/bmm/workflows/bmad-quick-flow/quick-spec/workflow.md, READ its entire contents and follow its directions exactly!
