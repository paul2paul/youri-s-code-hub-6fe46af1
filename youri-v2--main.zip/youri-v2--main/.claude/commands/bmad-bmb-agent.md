---
name: 'agent'
description: 'Tri-modal workflow for creating, editing, and validating BMAD Core compliant agents'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @{project-root}/_bmad/bmb/workflows/agent/workflow.md, READ its entire contents and follow its directions exactly!
